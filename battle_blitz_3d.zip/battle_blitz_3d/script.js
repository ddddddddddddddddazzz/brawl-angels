import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.164.1/build/three.module.js';

const $ = id => document.getElementById(id);
const host = $('scene'), stage = $('stage');
const ui = {overlay:$('overlay'), title:$('overlay-title'), copy:$('overlay-copy'), play:$('play'), kos:$('kos'), left:$('bots-left'), state:$('state-pill'), hp:$('hp-fill'), hpText:$('hp-text'), ammo:$('ammo-text'), pips:[...document.querySelectorAll('#ammo-pips i')], super:$('super-button'), superText:$('super-text'), superFill:$('super-fill'), objective:$('objective-text'), toast:$('toast'), crosshair:$('crosshair')};

const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.setSize(host.clientWidth, host.clientHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
host.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color('#91d5d0');
scene.fog = new THREE.Fog('#91d5d0', 28, 58);
const camera = new THREE.PerspectiveCamera(49, host.clientWidth/host.clientHeight, .1, 100);
scene.add(new THREE.HemisphereLight(0xe0ffff, 0x39513b, 2.2));
const sun = new THREE.DirectionalLight(0xffefce, 2.7); sun.position.set(-8,18,8); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024); sun.shadow.camera.left=-24; sun.shadow.camera.right=24; sun.shadow.camera.top=24; sun.shadow.camera.bottom=-24; scene.add(sun);
const fill = new THREE.DirectionalLight(0x8beaff, .9); fill.position.set(11,10,-9); scene.add(fill);

let seed=24681357; const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
const material=(c,r=.78,m=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
const M={grass:material('#64b960'),grassB:material('#57ad58'),grassDark:material('#478c4d'),border:material('#347a75'),wood:material('#98603b'),wood2:material('#c58b4b'),stone:material('#788f91'),stoneHi:material('#9db4ac'),bush:material('#21854c'),bush2:material('#42b95b'),dark:material('#19304a'),gun:material('#263b52',.38,.18),gold:material('#ffd45a',.4),white:material('#f5fbff',.4),player:material('#33daca',.36,.08),playerTrim:material('#b4fff1',.35),enemy1:material('#e65b61',.4),enemy2:material('#ff9e49',.4),enemy3:material('#a37bff',.4),enemy4:material('#589eff',.4),enemy5:material('#e66cbd',.4),bullet:material('#b7fff2',.25,.1),redBullet:material('#ff9d6f',.26,.05)};
function addMesh(parent,geo,mat,x=0,y=0,z=0,cast=true){const o=new THREE.Mesh(geo,mat);o.position.set(x,y,z);o.castShadow=cast;o.receiveShadow=true;parent.add(o);return o;}
function box(parent,mat,x,y,z,w,h,d){return addMesh(parent,new THREE.BoxGeometry(w,h,d),mat,x,y,z);}
function ball(parent,mat,x,y,z,r,seg=12){return addMesh(parent,new THREE.SphereGeometry(r,seg,Math.max(8,seg-2)),mat,x,y,z);}
function cylinder(parent,mat,x,y,z,rt,rb,h,s=12){return addMesh(parent,new THREE.CylinderGeometry(rt,rb,h,s),mat,x,y,z);}

// Stylized 3D arena ground, trim, props, bushes and rocks.
const floor=addMesh(scene,new THREE.PlaneGeometry(40,34),M.grass,0,-.25,0,false);floor.rotation.x=-Math.PI/2;
const base=box(scene,M.border,0,-.58,0,41,.65,35);
const grid=new THREE.GridHelper(38,28,0x74ce7b,0x74ce7b);grid.position.y=-.235;grid.material.transparent=true;grid.material.opacity=.17;scene.add(grid);
for(let x=-19;x<=19;x+=2.6){box(scene,M.border,x,-.02,-16.9,2.3,.34,.45);box(scene,M.border,x,-.02,16.9,2.3,.34,.45)}
for(let z=-14;z<=14;z+=2.6){box(scene,M.border,-19.9,-.02,z,.45,.34,2.3);box(scene,M.border,19.9,-.02,z,.45,.34,2.3)}
for(let i=0;i<300;i++){const x=(random()-.5)*37,z=(random()-.5)*31;if(Math.abs(x)>18||Math.abs(z)>15)continue;const blade=addMesh(scene,new THREE.ConeGeometry(.04,.15,4),random()>.5?M.grassB:M.grassDark,x,-.17,z,false);blade.rotation.z=(random()-.5)*.5;}
for(let i=0;i<34;i++){const x=(random()-.5)*35,z=(random()-.5)*29;const stem=cylinder(scene,M.grassDark,x,-.13,z,.025,.03,.13,5);const flower=ball(scene,[M.gold,M.playerTrim,M.enemy3][i%3],x,-.04,z,.055,8);flower.castShadow=false;}
const obstacles=[];
function addObstacle(x,z,w,d,type='crate',h=1.4){const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);if(type==='crate'){
  box(g,M.wood,0,h/2,0,w,h,d);box(g,M.wood2,0,h/2,d/2+.01,w*.86,.09,.035);box(g,M.wood2,0,h/2,-d/2-.01,w*.86,.09,.035);box(g,M.wood2,w/2+.01,h/2,0,.035,.09,d*.85);box(g,M.wood2,-w/2-.01,h/2,0,.035,.09,d*.85);box(g,M.wood2,0,h/2,0,w*.88,.07,.07);
}else if(type==='rock'){const r=addMesh(g,new THREE.DodecahedronGeometry(1,0),M.stone,0,h*.35,0);r.scale.set(w*.57,h*.6,d*.58);r.rotation.y=random()*3;const hi=addMesh(g,new THREE.DodecahedronGeometry(.7,0),M.stoneHi,-.18,h*.62,-.08);hi.scale.set(w*.32,h*.26,d*.3);
}else if(type==='bush'){for(let j=0;j<8;j++){const a=random()*Math.PI*2,r=random()*.6;const b=ball(g,j%3===0?M.bush2:M.bush,Math.cos(a)*w*.31*r,.3+random()*.32,Math.sin(a)*d*.31*r,.35+random()*.13,10);b.scale.y=.8;}
}else if(type==='barrel'){cylinder(g,M.wood,0,h*.35,0,w*.38,w*.38,h*.7,12);cylinder(g,M.stone,0,h*.16,0,w*.4,w*.4,.1,12);cylinder(g,M.stone,0,h*.58,0,w*.4,w*.4,.1,12);}
obstacles.push({x,z,w,d,r:Math.max(w,d)*.52,type,group:g});return g;}
addObstacle(-7,-7,2.2,1.7,'crate',1.6);addObstacle(-3,-9,2,2,'rock',1.5);addObstacle(4,-7,2,2,'crate',1.4);addObstacle(8,-3,2,1.8,'rock',1.5);addObstacle(-8,1,2,2,'rock',1.3);addObstacle(-3,3,2,1.8,'crate',1.5);addObstacle(3,2,2.1,2.1,'crate',1.5);addObstacle(8,6,2.3,1.8,'crate',1.5);addObstacle(-8,8,2.3,2.3,'bush',1);addObstacle(-1,-2,2.6,2.2,'bush',1);addObstacle(6,-11,2.8,2.2,'bush',1);addObstacle(1,9,1.8,1.8,'barrel',1.5);addObstacle(11,1,1.5,1.5,'barrel',1.4);addObstacle(-12,-5,2,2,'bush',1);addObstacle(12,10,2.2,2.2,'bush',1);
for(let i=0;i<24;i++){const x=(random()>.5?1:-1)*(14+random()*3.5),z=(random()-.5)*28;cylinder(scene,M.wood,x,.45,z,.16,.22,.9,7);ball(scene,i%2?M.bush:M.bush2,x,1.25,z,.7,10);ball(scene,M.bush,x+.28,1.1,z+.24,.43,9);}

function fighter({x,z,player=false,color=M.enemy1,accent=M.gold,name='BOT',hp=600,speed=4,style=0}){
 const root=new THREE.Group();root.position.set(x,0,z);scene.add(root);const rig=new THREE.Group();root.add(rig);
 const shadow=addMesh(root,new THREE.CircleGeometry(.66,20),new THREE.MeshBasicMaterial({color:0x172c36,transparent:true,opacity:.25,depthWrite:false}),0,.02,0,false);shadow.rotation.x=-Math.PI/2;
 const legs=[];for(const s of [-1,1]){const leg=new THREE.Group();leg.position.set(s*.2,.55,0);rig.add(leg);addMesh(leg,new THREE.CapsuleGeometry(.12,.3,4,8),M.dark,0,-.1,0);box(leg,accent,0,-.28,.08,.26,.12,.3);legs.push(leg);}
 const torso=addMesh(rig,new THREE.CapsuleGeometry(.38,.42,4,10),color,0,1.08,0);torso.scale.z=.84;
 const chest=ball(rig,accent,0,1.36,.02,.32);chest.scale.set(1,.3,.7);
 const head=new THREE.Group();head.position.set(0,1.78,0);rig.add(head);ball(head,color,0,0,0,.39,14);const helmet=ball(head,accent,0,.22,-.01,.33,12);helmet.scale.set(1,.44,.92);box(head,M.dark,0,.02,.34,.48,.18,.1);box(head,player?M.playerTrim:M.white,0,.02,.395,.3,.055,.035);
 const arms=[];for(const s of [-1,1]){const arm=new THREE.Group();arm.position.set(s*.43,1.35,0);rig.add(arm);addMesh(arm,new THREE.CapsuleGeometry(.12,.33,4,8),color,s*.07,-.17,.03);ball(arm,accent,s*.07,-.36,.08,.12,9);arms.push(arm);}
 const weapon=new THREE.Group();weapon.position.set(.43,1.23,.22);rig.add(weapon);box(weapon,M.gun,0,0,.27,.23,.2,.58);box(weapon,accent,0,.07,.31,.25,.065,.26);cylinder(weapon,M.dark,0,0,.58,.09,.09,.17,9).rotation.x=Math.PI/2;ball(weapon,player?M.playerTrim:M.gold,0,0,.67,.075,8);
 const hpGroup=new THREE.Group();hpGroup.position.set(0,2.55,0);root.add(hpGroup);addMesh(hpGroup,new THREE.PlaneGeometry(1,.11),M.dark,0,0,0,false);const hpFill=addMesh(hpGroup,new THREE.PlaneGeometry(.92,.055),player?M.playerTrim:M.enemy1,0,0,.012,false);
 return {root,rig,legs,arms,head,weapon,shadow,hpGroup,hpFill,player,name,hp,maxHp:hp,speed,style,alive:true,radius:player?.46:.44,fire:0,hit:0,invuln:0,ammo:3,reload:0,super:0,anim:random()*5,strafe:random()>.5?1:-1,brain:random()*.4,dodge:0,dodgeX:0,dodgeZ:0};
}
const player=fighter({x:0,z:12,player:true,color:M.player,accent:M.gold,name:'VOLT',hp:1000,speed:7});
const botSpecs=[{x:-13,z:-11,hp:620,speed:3.7,style:0,color:M.enemy1,name:'BRUISER'},{x:0,z:-12,hp:510,speed:5.4,style:1,color:M.enemy2,name:'DASHER'},{x:13,z:-9,hp:450,speed:3.2,style:2,color:M.enemy3,name:'SNIPER'},{x:-13,z:6,hp:550,speed:4.7,style:3,color:M.enemy4,name:'SCOUT'},{x:12,z:11,hp:800,speed:2.9,style:4,color:M.enemy5,name:'TANK'}];
let bots=[],bullets=[],particles=[],gameState='menu',kills=0,mouse={x:innerWidth/2,y:innerHeight/2,down:false},keys={},toastTimer=0,lastTime=0;
const raycaster=new THREE.Raycaster(),plane=new THREE.Plane(new THREE.Vector3(0,1,0),0),clock=new THREE.Clock();
const temp=new THREE.Vector3();
function resetBots(){for(const b of bots)scene.remove(b.root);bots=botSpecs.map(s=>fighter({...s,accent:s.style%2?M.white:M.gold}));}
function living(){return bots.filter(b=>b.alive);}
function hud(){ui.kos.textContent=kills;ui.left.textContent=living().length;ui.hp.style.width=`${Math.max(0,player.hp)/player.maxHp*100}%`;ui.hp.style.background=player.hp<300?'linear-gradient(90deg,#ff576b,#ffad62)':'linear-gradient(90deg,#26dcb3,#a5ff75)';ui.hpText.textContent=`${Math.ceil(Math.max(0,player.hp))} / ${player.maxHp}`;ui.ammo.textContent=`${player.ammo} / 3`;ui.pips.forEach((p,i)=>p.classList.toggle('empty',i>=player.ammo));ui.superFill.style.width=player.super+'%';ui.superText.textContent=player.super>=100?'READY · SPACE':`${Math.floor(player.super)}% CHARGED`;ui.super.disabled=player.super<100||gameState!=='playing';ui.state.textContent=gameState==='playing'?'FIGHT IN PROGRESS':gameState==='won'?'VICTORY!':gameState==='lost'?'DEFEATED':'READY TO FIGHT';}
function toast(text){ui.toast.textContent=text;ui.toast.classList.add('show');toastTimer=1.25;}
function startGame(){for(const b of bullets){scene.remove(b.mesh);scene.remove(b.glow);}bullets=[];for(const p of particles)scene.remove(p.mesh);particles=[];kills=0;player.hp=player.maxHp;player.ammo=3;player.reload=0;player.super=0;player.invuln=1;player.alive=true;player.root.visible=true;player.shadow.visible=true;player.hpGroup.visible=true;player.root.position.set(0,0,12);player.root.rotation.set(0,0,0);player.fire=0;resetBots();gameState='playing';ui.overlay.classList.add('hidden');ui.objective.textContent='TAKE OUT THE BOTS';toast('GO! GO! GO!');hud();}
function endGame(won){if(gameState!=='playing')return;gameState=won?'won':'lost';ui.title.innerHTML=won?'ARENA <em>CHAMPION</em>':'BACK TO <em>THE LOBBY</em>';ui.copy.textContent=won?`All bots defeated. You scored ${kills} KOs. Nice work!`:`You scored ${kills} KOs. Reboot and try a new strategy.`;ui.play.innerHTML='PLAY AGAIN <b>➜</b>';ui.overlay.classList.remove('hidden');ui.objective.textContent=won?'ARENA CLEARED':'YOU WERE ELIMINATED';hud();}
function moveCrosshair(){const rect=stage.getBoundingClientRect();ui.crosshair.style.left=(mouse.x-rect.left)+'px';ui.crosshair.style.top=(mouse.y-rect.top)+'px';}
function aimAtPointer(){const rect=renderer.domElement.getBoundingClientRect();const ndc=new THREE.Vector2(((mouse.x-rect.left)/rect.width)*2-1,-((mouse.y-rect.top)/rect.height)*2+1);raycaster.setFromCamera(ndc,camera);const p=new THREE.Vector3();if(raycaster.ray.intersectPlane(plane,p))return p;return null;}
function nearestBot(from=player.root.position){let best=null,ds=Infinity;for(const b of living()){const d=b.root.position.distanceToSquared(from);if(d<ds){best=b;ds=d;}}return best;}
function spawnBullet(owner,origin,direction,damage,speed,color,radius=.13){const geo=new THREE.SphereGeometry(radius,10,8);const mat=new THREE.MeshStandardMaterial({color,emissive:color,emissiveIntensity:1.4,roughness:.25});const m=addMesh(scene,geo,mat,origin.x,origin.y,origin.z,false);const glow=addMesh(scene,new THREE.SphereGeometry(radius*2,8,6),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.22,depthWrite:false}),origin.x,origin.y,origin.z,false);bullets.push({owner,mesh:m,glow,vel:direction.clone().multiplyScalar(speed),damage,life:2.4,radius});}
function firePlayer(){if(gameState!=='playing'||player.fire>.0||player.reload>.0)return;if(player.ammo<=0){player.reload=1.05;toast('RELOADING');return;}let target=aimAtPointer();if(!target){const b=nearestBot();if(!b)return;target=b.root.position.clone();}const origin=player.root.position.clone().add(new THREE.Vector3(0,1.25,0));const dir=target.clone().sub(origin);dir.y=0;if(dir.lengthSq()<.01)return;dir.normalize();player.root.rotation.y=Math.atan2(dir.x,dir.z);spawnBullet(player,origin,dir,145,18,0x8ffff0,.15);player.ammo--;player.fire=.23;player.super=Math.min(100,player.super+7);player.rig.scale.y=.94;hud();}
function fireBot(bot){const origin=bot.root.position.clone().add(new THREE.Vector3(0,1.2,0));const target=player.root.position.clone().add(new THREE.Vector3(0,.85,0));const dir=target.sub(origin);dir.y=0;if(dir.lengthSq()<.01)return;dir.normalize();const isSniper=bot.style===2,isTank=bot.style===4;dir.applyAxisAngle(new THREE.Vector3(0,1,0),(random()-.5)*(isSniper?.035:.16));bot.root.rotation.y=Math.atan2(dir.x,dir.z);spawnBullet(bot,origin,dir,isSniper?100:isTank?78:62,isSniper?22:12,0xff9b70,.12);bot.fire=isSniper?1.25:isTank?.92:.78;}
function burst(pos,color,count=10){for(let i=0;i<count;i++){const m=addMesh(scene,new THREE.SphereGeometry(.06+random()*.06,7,6),new THREE.MeshBasicMaterial({color,transparent:true}),pos.x,pos.y,pos.z,false);particles.push({mesh:m,life:.35+random()*.35,max:.7,velocity:new THREE.Vector3((random()-.5)*5,random()*3,(random()-.5)*5)});}}
function damage(target,amount,source){if(!target.alive||target.invuln>0)return;target.hp-=amount;target.hit=.14;if(target===player)target.invuln=.15;burst(target.root.position.clone().add(new THREE.Vector3(0,1,0)),target.player?0x8affed:0xffa064,5);if(target.hp<=0){target.hp=0;target.alive=false;target.root.visible=false;target.shadow.visible=false;target.hpGroup.visible=false;if(target===player){endGame(false);}else{kills++;player.super=Math.min(100,player.super+13);toast(`${target.name} ELIMINATED`);if(!living().length)endGame(true);}}hud();}
function useSuper(){if(gameState!=='playing'||player.super<100)return;player.super=0;const p=player.root.position;const ring=addMesh(scene,new THREE.TorusGeometry(7.2,.14,8,64),new THREE.MeshBasicMaterial({color:0x75fff0,transparent:true,opacity:.9}),p.x,.12,p.z,false);ring.rotation.x=Math.PI/2;particles.push({mesh:ring,life:.55,max:.55,ring:true});for(const b of living()){const d=b.root.position.clone().sub(p);d.y=0;if(d.length()<7.2){damage(b,260,player);d.normalize().multiplyScalar(2.3);b.root.position.add(d);}}for(let i=0;i<36;i++){const a=i/36*Math.PI*2;const m=addMesh(scene,new THREE.SphereGeometry(.1,8,6),new THREE.MeshBasicMaterial({color:i%2?0x62ffe5:0xffdf73}),p.x,.6,p.z,false);particles.push({mesh:m,life:.55,max:.55,velocity:new THREE.Vector3(Math.cos(a)*5,random()*2,Math.sin(a)*5)});}toast('SUPER BLAST!');hud();}
function collides(x,z,r){if(Math.abs(x)>18.9-r||Math.abs(z)>15.9-r)return true;for(const o of obstacles){if(o.type==='bush')continue;const dx=x-o.x,dz=z-o.z;const rx=r+o.w*.42,rz=r+o.d*.42;if(Math.abs(dx)<rx&&Math.abs(dz)<rz)return true;}return false;}
function moveEntity(e,dx,dz){const x=e.root.position.x,z=e.root.position.z,r=e.radius;if(!collides(x+dx,z,r))e.root.position.x=x+dx;if(!collides(e.root.position.x,z+dz,r))e.root.position.z=z+dz;}
function updatePlayer(dt){const e=player;let dx=0,dz=0;if(keys.KeyA||keys.ArrowLeft)dx--;if(keys.KeyD||keys.ArrowRight)dx++;if(keys.KeyW||keys.ArrowUp)dz--;if(keys.KeyS||keys.ArrowDown)dz++;const mag=Math.hypot(dx,dz);if(mag){dx/=mag;dz/=mag;moveEntity(e,dx*e.speed*dt,dz*e.speed*dt);e.anim+=dt*11;}else e.anim+=dt*2.5;
 const target=aimAtPointer();if(target){const d=target.clone().sub(e.root.position);d.y=0;if(d.lengthSq()>.08)e.root.rotation.y=Math.atan2(d.x,d.z);}if(mouse.down)firePlayer();
 if(e.fire>0)e.fire-=dt;if(e.reload>0){e.reload-=dt;if(e.reload<=0){e.ammo=3;toast('AMMO READY');}}if(e.ammo===0&&e.reload<=0)e.reload=1.05;if(e.invuln>0)e.invuln-=dt;if(e.hit>0)e.hit-=dt;
 e.rig.scale.y=THREE.MathUtils.lerp(e.rig.scale.y,1,Math.min(1,dt*12));const moving=mag>0;e.legs.forEach((leg,i)=>{leg.rotation.x=moving?Math.sin(e.anim+(i*Math.PI))*0.55:Math.sin(e.anim)*.035;});e.arms.forEach((arm,i)=>{arm.rotation.x=(i===1?-.28:.1)+(moving?Math.sin(e.anim+i)*.08:0);});e.head.rotation.y=Math.sin(e.anim*.3)*.04;
}
function updateBots(dt){for(const b of bots){if(!b.alive)continue;b.fire=Math.max(0,b.fire-dt);b.brain-=dt;b.invuln=Math.max(0,b.invuln-dt);b.hit=Math.max(0,b.hit-dt);b.anim+=dt*(b.style===1?12:8);
 const p=b.root.position,pp=player.root.position;let dx=pp.x-p.x,dz=pp.z-p.z,dist=Math.hypot(dx,dz)||.01;dx/=dist;dz/=dist;
 if(b.brain<=0){b.brain=.25+random()*.35;if(dist<4.4){b.ai='retreat';b.strafe=random()>.5?1:-1;}else if(dist>9){b.ai='approach';}else{b.ai='strafe';if(random()<.17)b.strafe*=-1;}if(random()<.13&&dist<8){b.dodge=.28;b.dodgeX=-dz*b.strafe*1.4;b.dodgeZ=dx*b.strafe*1.4;}}
 let mx=0,mz=0;const isSniper=b.style===2,isDasher=b.style===1,isTank=b.style===4;const ideal=isSniper?10:isTank?4.5:6;
 if(dist>ideal+.8){mx+=dx;mz+=dz;}else if(dist<ideal-1.2){mx-=dx*.9;mz-=dz*.9;}
 if(dist<11){mx+=-dz*b.strafe*(isSniper?.7:.55);mz+=dx*b.strafe*(isSniper?.7:.55);}
 if(b.dodge>0){b.dodge-=dt;mx+=b.dodgeX;mz+=b.dodgeZ;}
 // Brief dash patterns make the fast bot feel distinct.
 if(isDasher&&dist>4&&dist<8&&random()<.018){mx+=dx*2.4;mz+=dz*2.4;}
 const ml=Math.hypot(mx,mz);if(ml>.01){mx/=ml;mz/=ml;moveEntity(b,mx*b.speed*dt,mz*b.speed*dt);}
 if(dist<14&&b.fire<=0)fireBot(b);
 b.root.rotation.y=Math.atan2(dx,dz);b.legs.forEach((leg,i)=>leg.rotation.x=ml>.1?Math.sin(b.anim+i*Math.PI)*.48:0);b.arms.forEach((arm,i)=>arm.rotation.x=Math.sin(b.anim*.35+i)*.035);
 }}
function updateBullets(dt){for(let i=bullets.length-1;i>=0;i--){const b=bullets[i];b.life-=dt;b.mesh.position.addScaledVector(b.vel,dt);b.glow.position.copy(b.mesh.position);let hit=null;if(b.owner===player){for(const e of bots){if(!e.alive)continue;const dx=e.root.position.x-b.mesh.position.x,dz=e.root.position.z-b.mesh.position.z;if(dx*dx+dz*dz<(.57+b.radius)**2&&Math.abs(b.mesh.position.y-1)<1.3){hit=e;break;}}}else{const dx=player.root.position.x-b.mesh.position.x,dz=player.root.position.z-b.mesh.position.z;if(dx*dx+dz*dz<(.58+b.radius)**2&&Math.abs(b.mesh.position.y-1)<1.3)hit=player;}
 let wall=false;for(const o of obstacles){if(o.type==='bush')continue;if(Math.abs(b.mesh.position.x-o.x)<o.w*.46&&Math.abs(b.mesh.position.z-o.z)<o.d*.46&&b.mesh.position.y<2.1){wall=true;break;}}
 if(hit){damage(hit,b.damage,b.owner);burst(b.mesh.position.clone(),b.owner===player?0x82fff1:0xff946a,5);}if(hit||wall||b.life<=0||Math.abs(b.mesh.position.x)>21||Math.abs(b.mesh.position.z)>18){scene.remove(b.mesh);scene.remove(b.glow);bullets.splice(i,1);}}
}
function updateParticles(dt){for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=dt;if(p.velocity)p.mesh.position.addScaledVector(p.velocity,dt);if(p.ring){const scale=1+(p.max-p.life)*1.2;p.mesh.scale.setScalar(scale);p.mesh.material.opacity=Math.max(0,p.life/p.max);}else if(p.mesh.material&&'opacity'in p.mesh.material)p.mesh.material.opacity=Math.max(0,p.life/p.max);if(p.life<=0){scene.remove(p.mesh);particles.splice(i,1);}}}
function updateCamera(dt){const p=player.root.position;const desired=new THREE.Vector3(p.x,p.y+15,p.z+17);camera.position.lerp(desired,1-Math.exp(-dt*3.6));camera.lookAt(p.x,p.y+.3,p.z-1.5);const alive=player.alive;ui.objective.textContent=alive?(living().length?'TAKE OUT THE BOTS':'ARENA CLEARED'):'YOU WERE ELIMINATED';for(const c of [player,...bots])if(c.hpGroup.visible){c.hpGroup.quaternion.copy(camera.quaternion);c.hpFill.scale.x=Math.max(.001,c.hp/c.maxHp);c.hpFill.position.x=-(1-c.hp/c.maxHp)*.46;}}
function resize(){const w=host.clientWidth,h=host.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));renderer.setSize(w,h);}
function frame(){requestAnimationFrame(frame);const dt=Math.min(clock.getDelta(),.035);if(gameState==='playing'){updatePlayer(dt);updateBots(dt);updateBullets(dt);updateParticles(dt);if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)ui.toast.classList.remove('show');}}else updateParticles(dt);updateCamera(dt);hud();renderer.render(scene,camera);}

ui.play.addEventListener('click',startGame);ui.super.addEventListener('click',useSuper);
window.addEventListener('keydown',e=>{keys[e.code]=true;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();if(e.code==='Space')useSuper();});window.addEventListener('keyup',e=>{keys[e.code]=false;});
renderer.domElement.addEventListener('pointermove',e=>{mouse.x=e.clientX;mouse.y=e.clientY;moveCrosshair();});renderer.domElement.addEventListener('pointerdown',e=>{if(e.button===0){mouse.down=true;mouse.x=e.clientX;mouse.y=e.clientY;moveCrosshair();firePlayer();}});window.addEventListener('pointerup',()=>{mouse.down=false;});renderer.domElement.addEventListener('contextmenu',e=>e.preventDefault());
window.addEventListener('resize',resize);
resetBots();player.hpGroup.visible=true;hud();resize();frame();
