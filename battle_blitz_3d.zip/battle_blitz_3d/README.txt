BATTLE BLITZ 3D - GitHub Pages setup

Files:
- index.html
- style.css
- script.js

To publish:
1. Open your GitHub repository.
2. Upload all three files to the repository root (same folder).
3. Commit the changes.
4. Open your GitHub Pages URL and refresh.

Notes:
- This uses Three.js from a public CDN, so the game needs an internet connection.
- Open with GitHub Pages or another local web server; ES modules usually do not work when opening index.html directly as a file.
- Controls: WASD / arrow keys move, move mouse to aim, hold/click left mouse to shoot, Space or the Super Blast button uses the super.
